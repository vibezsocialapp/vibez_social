# Vibez 🌴 — deployment and feature status

## What works in this prototype
- Responsive purple tropical UI with a vertical swipe/scroll-snap For You feed.
- Demo reactions and comments, local video file preview, caption/hashtag entry, device-only profile, device-only marketplace listings in community/business categories, sharing the site URL, navigation and installable PWA metadata.
- Optional Supabase email/password sign-up, sign-in and sign-out once configured. Passwords are managed by Supabase, not local storage.

## Not implemented yet
Public persistent video uploads/storage and feeds, follows, messages, notifications, search across users, live streaming, animations, paid DJ/creator rooms, creator-owned paid servers, wallet/gifts/credit-card payments, subscriptions, ads, creator payouts, checkout, reporting/blocking/moderation workflows. Buttons for these are demonstrations or marked planned. Do not publicly advertise them as functional.

## Deploy to Vercel
1. Create a Vercel account and GitHub account. Create a new GitHub repository and upload all files in this folder to the repository root.
2. Import that repository at https://vercel.com/new, name it `vibez-social` (if available), choose Other as framework and deploy. The address `vibez-social.vercel.app` is not guaranteed until Vercel confirms it.
3. Open https://supabase.com/dashboard and create a project. Under Project Settings > API, copy the Project URL and **publishable or anon** key. Paste into `config.js`. NEVER put a service_role or secret key in front-end files. Commit and redeploy.
4. Under Supabase Authentication > URL Configuration set the confirmed live URL as Site URL and allow it in Redirect URLs. Configure a production email sender, email verification, password policy and anti-abuse/rate limiting.
5. Test sign-up, confirmation, sign-in and sign-out with two separate test accounts before sharing. Verify HTTPS, Safari, Android install, and offline shell.
6. Before inviting public users, implement policies, age protections, moderation, reporting, account deletion, security and privacy disclosures. For public videos, use authenticated storage, access policies and upload limits.

## Mobile installs
- Android: open deployed HTTPS website in Chrome, choose Install app / Add to Home Screen.
- iPhone: open in Safari, Share > Add to Home Screen > Add.
- Apple App Store and Google Play distribution require separate app packaging, developer accounts and review. A PWA is not automatically listed in either store.

## Future implementation architecture
Supabase Auth + Postgres with row-level security, object storage and video transcoding/CDN, WebRTC streaming infrastructure, payment provider for creator fees/gifts and marketplace, notification service, moderation and abuse reporting, creator dashboard and admin tools. Do not process card details directly in browser code.
